from django.apps import AppConfig


class TwitterreportConfig(AppConfig):
    name = 'TwitterReport'

def hi():
    print('printed from crontab')
    f= open('C:/Users/Auburn/Desktop/cron.txt','w')
    f.close()